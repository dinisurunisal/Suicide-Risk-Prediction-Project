const jwt = require('jsonwebtoken');
const config = require('../../config.json');
const mySql = require("../../sql");
const axios = require('axios');

/*
Add patient Record
Search patient Record by year/year+month
Get all Patients Records of a patient
Delete selected patient Record
get records asc by date
get records desc ny date
*/

//----Adding a patient record-------
exports.add_patientRecord = async function (req, res, next) {
    let result = "Negative";
    const prediction = await axios({
        method: 'post',
        url: 'http://127.0.0.1:5000/predict',
        withCredentials: true,
        crossdomain: true,
        headers: { 'Content-Type': 'application/json' },
        data: req.body,
    }).catch(e => e)
    if (prediction instanceof Error) {
        result = "Cannot say Exactly";
        console.log('Error E:', prediction)
    } else {
        result = prediction['data']['Prediction'];
    }
    console.log(prediction['data']['Prediction']);
    let values = [
        req.body.NIC,
        req.body.Age,
        new Date(),
        req.body.Religon,
        req.body.Race,
        req.body.Gender,
        req.body.Nature_Of_Occupation,
        req.body.Civil_Status,
        req.body.Education_Level,
        req.body.Reason,
        req.body.Lifetime_Psychiatric_Hospitalizations,
        req.body.Past_Suicide_Attempts,
        req.body.Any_suicidal_thoughts_mentioned,
        req.body.Self_Injurious_Behaviour,
        req.body.Psychiatric_Disorders,
        req.body.Past_Illnesses,
        req.body.Alcohol_drug_Consumption,
        req.body.Anger,
        req.body.Sleep_Problem,
        req.body.Social_Iscolation,
        req.body.Sad_Weary,
        req.body.Humilated,
        req.body.deleted,
        req.body.patientId,
        req.body.ID];

    let sql = "INSERT INTO patientrecords(NIC,age,date,religon,race,gender,occupation,civilStatus,educationalLevel,reason,lifeTimePsychiatricHospitalizations,pastSuicideAttempts,anySuicidalThoughts,selfInjuriousBehaviour,psychiatricDisorders,pastIllness,alcoholConsumption,anger,sleepProblem,socialIsolation,sad, humiliated,deleted,patientId,ID,result) VALUES  (?,?)";
    mySql.query(sql, [values, result], (err, rows, fields) => {
        if (err === null) {
            console.log("Patient record added successfully");
            res.status(201).send({ success: true, message: "Patient Record successfully added!", 'RecordID': rows.insertId });
        } else {
            console.log(err)
            res.status(422).send({ success: false, message: "Data incorrect or incomplete" });
        }
    });
}

//----get patient records of a specific patient of a specific doctor
exports.all_RecordOFaPatient = function (req, res, next) {
    let patient_id = req.body.patient_id;
    let doc_id = req.body.doc_id;
    let sql = 'SELECT * FROM patientrecords where patientId = ? and ID = ?';
    mySql.query(sql, [patient_id, doc_id], (err, rows, fields) => {
        if (rows.length != 0) {
            console.log(rows);
            res.status(200).send({ success: true, rows });
        } else {
            console.log(err);
            res.status(404).send({ success: true, message: "No patients found" });
        }
    });

}

//----Getiing one record of a patient
exports.get_patientRecord = function (req, res, next) {
    let recordId = req.params.recordId;
    let sql = 'SELECT * FROM patientrecords WHERE recordId = ?';
    mySql.query(sql, [recordId], (err, rows, fields) => {
        if (rows.length != 0) {
            console.log(rows);
            res.status(200).send({ success: true, rows });
        } else {
            console.log(err);
            res.status(404).send({ success: true, message: "No matching patient record found" });
        }
    });

}

exports.delete_patientRecord = function (req, res, next) {
    let recordId = req.params.recordId;
    let sql_ = 'SELECT * FROM patientrecords WHERE recordId =?';
    mySql.query(sql_, [recordId], (err, rows, fields) => {
        console.log("Total Records:- " + rows.length);
        if (rows.length != 0) {
            let sql_ = 'DELETE FROM patientrecords WHERE recordId=?';
            mySql.query(sql_, [recordId], (err, rows, fields) => {
                res.status(200).send({ success: true, message: "Patient record successfully deleted.!" });
            });
        } else {
            res.status(404).send({ success: false, message: "No patient records" });
        }
    });

}

//order the records by descending order
exports.order_by_old = function (req, res, next) {
    let NICpatient = req.body.NIC;
    let ID = req.body.ID;
    let sql = 'SELECT * FROM patientrecords ORDER BY date DESC where NIC = ? and ID = ?';
    mySql.query(sql, [NICpatient, ID], (err, rows, fields) => {
        if (rows.length != 0) {
            console.log(rows);
            res.status(200).send({ success: true, rows });
        } else {
            console.log(err);
            res.status(404).send({ success: true, message: "No patients found" });
        }
    });

}
//SELECT * FROM members ORDER BY date_of_birth DESC;
exports.order_by_new = function (req, res, next) {
    let NICpatient = req.body.NIC;
    let ID = req.body.ID;
    let sql = 'SELECT * FROM patientrecords ORDER BY date ASC  where NIC = ? and ID = ?';
    mySql.query(sql, [NICpatient, ID], (err, rows, fields) => {
        if (rows.length != 0) {
            console.log(rows);
            res.status(200).send({ success: true, rows });
        } else {
            console.log(err);
            res.status(404).send({ success: true, message: "No patients found" });
        }
    });
}
