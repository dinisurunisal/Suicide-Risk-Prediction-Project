const express = require('express');
const bodyparser = require('body-parser');

const users = require('./Server/routes/user-routes');
const patients = require('./Server/routes/patient-routes');
const patient_records = require('./Server/routes/patientRecords-routes');
const cors = require('cors');
const axios = require('axios')
const app = express();
const port = process.env.PORT || 8080;

const message = `Please send a GET request to /predict
`
app.use(cors()) // U

app.use(bodyparser.urlencoded({ extended: false }));
app.use(bodyparser.json());
app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT,DELETE");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization,access-control-allow-origin");
    next();
});
const allowedOrigins = [
    'capacitor://localhost',
    'ionic://localhost',
    'http://localhost',
    'http://localhost:8080',
    'http://localhost:8100',
    'http://localhost:8200',
    'http://192.168.43.158:8100'
  ];
  
  // Reflect the origin if it's in the allowed list or not defined (cURL, Postman, etc.)
  const corsOptions = {
    origin: (origin, callback) => {
      if (allowedOrigins.includes(origin) || !origin) {
        callback(null, true);
      } else {
        callback(new Error('Origin not allowed by CORS'));
      }
    }
  }
  
  // Enable preflight requests for all routes
  app.options('*', cors(corsOptions));
  
  app.get('/', cors(corsOptions), (req, res, next) => {
    res.json({ message: 'This route is CORS-enabled for an allowed origin.' });
  })

app.use(bodyparser.json());

/* Manage CORS Access for ALL requests/responses */
app.use(function(req, res, next)
{
   /* Allow access from any requesting client */
   res.setHeader('Access-Control-Allow-Origin', '*');

   /* Allow access for any of the following Http request types */
   res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, PUT');

   /* Set the Http request header */
   res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type,Authorization');

   res.setHeader('Content-Type', 'application/json');
    next();
});
app.get('/api',(req,res)=>{
	res.sendStatus(200); //ok status
});

app.post('/prediction', async (req, res) => {

    console.log(req.body);
  
      const prediction = await axios({
        method: 'post',
        url: 'http://127.0.0.1:5000/predict',
        withCredentials: true,
        crossdomain: true,
        headers: { 'Content-Type': 'application/json' },
        data: req.body,
      }).catch(e => e)
      if (prediction instanceof Error) {
        console.log('the error', prediction)
        return
      }
      res.send(prediction.data)
      console.log(prediction.data)
      return
  })
  
  app.use('*', (req, res) => { 
    res.status(400).send(message)
  })
  

app.use('/user', users);
app.use('/patient', patients);
app.use('/patientRecords', patient_records);

app.listen(port, () => {
    console.log('Server started on port ' + port);
});
