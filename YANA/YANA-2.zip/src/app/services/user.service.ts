import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    // tslint:disable-next-line:object-literal-key-quotes
    'Authorization': 'Bearer ' + localStorage.getItem('token')
  });
  private jwtHelper = new JwtHelperService();

  constructor(private http: HttpClient) { }

  public login(email, password) {
    // tslint:disable-next-line:object-literal-key-quotes
    return this.http.post('http://localhost:8080/user/login', { 'email': email, 'password': password }).pipe(map(res => res));
  }

  public register(email, NIC, firstname, phonenumber, address, password) {
    return this.http.post('http://localhost:8080/user/register',
      // tslint:disable-next-line:object-literal-key-quotes
      { 'nIC': NIC, 'email': email, 'firstname': firstname, 'phonenumber': phonenumber, 'address': address, 'password': password }).pipe(map(res => res));
  }

  public isAuthenticated(): boolean {
    if (localStorage.getItem('token') !== null) {
      const token = localStorage.getItem('token');
      return !this.jwtHelper.isTokenExpired(token);
    } else {
      return false;
    }
  }

  public forgetPassword(email) {
    // tslint:disable-next-line:object-literal-key-quotes
    return this.http.post('http://localhost:8080/user/forgetpassword', { 'email': email }).pipe(map(res => res));
  }

  public getAllPatients(id) {
    // tslint:disable-next-line:object-literal-key-quotes
    return this.http.get('http://localhost:8080/patient/allPatients/' + id, { headers: this.headers }).pipe(map(res => res));
  }

  public getPatientRecords(docId, patientId) {
    // tslint:disable-next-line:object-literal-key-quotes
    return this.http.post('http://localhost:8080/patientRecords/allRecordsOfAPatient/', { 'doc_id': docId, 'patient_id': patientId }, { headers: this.headers }).pipe(map(res => res));
  }

  public getPatientRecordsDetails(recordID) {
    // tslint:disable-next-line:object-literal-key-quotes
    return this.http.get('http://localhost:8080/patientRecords/oneRecord/' + recordID, { headers: this.headers }).pipe(map(res => res));
  }

  public addPatient(docId, NIC) {
    // tslint:disable-next-line:object-literal-key-quotes
    return this.http.post('http://localhost:8080/patient/addPatient', { 'doc_id': docId, 'NIC': NIC }, { headers: this.headers }).pipe(map(res => res));
  }

  public deletePatient(patientId) {
    // tslint:disable-next-line:object-literal-key-quotes
    return this.http.delete('http://localhost:8080/patient/delete/' + patientId, { headers: this.headers }).pipe(map(res => res));
  }
}
