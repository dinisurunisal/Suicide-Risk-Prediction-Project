import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';


import { Component } from '@angular/core';
import { Router } from '@angular/router';


import { LoginPage } from './login.page';



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild([
      {
        path: '',
        component: LoginPage
      }
    ])
  ],
  declarations: [LoginPage]
})
export class LoginPageModule {
  projects: any = [];
  project: string;

  constructor(private route: Router) { }

  nextpage() {
    this.route.navigate(['/home.page.html']);
  }
}
