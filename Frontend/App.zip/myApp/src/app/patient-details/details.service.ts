import { Injectable } from '@angular/core';
import { Details } from './patient-details.module';

@Injectable({
  providedIn: 'root'
})
export class DetailsService {
  details:Details[]=[
    {
    id:'result1',
    result:'string'
    },
    {
      id:'result2',
      result:'string'
      }
  ]

  constructor() { }
  gellAllDetails(){
    return[...this.details];
  }
  
  getDetails(result: string){
    return {
      ...this.details.find(details => {
      return details.result  === result;
      })
    };
  }
}
