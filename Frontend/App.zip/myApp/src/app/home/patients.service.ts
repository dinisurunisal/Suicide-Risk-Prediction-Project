import { Injectable } from '@angular/core';
import { Patient } from './home.module';
import { PatientDetailsPageRoutingModule } from '../patient-details/patient-details-routing.module';

@Injectable({
  providedIn: 'root'
})
export class PatientsService {
  private patients: Patient [] =[
    {
      title:'996749940v',
      imageUrl:''
    },
    {
      title:'20017695378',
      imageUrl:''
    }
  ]

  constructor() { }



  gellAllPatients(){
    return[...this.patients];
  }
  
  getPatient(title: string){
    return {
      ...this.patients.find(patient => {
      return patient.title === title;
      })
    };
  }
}
