(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["account-settings-account-settings-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/account-settings/account-settings.page.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/account-settings/account-settings.page.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n  <ion-menu side=\"start\" content-id=\"main-content\">\n    <ion-header>\n      <ion-toolbar translucent>\n        <ion-title class=\"title\">Menu</ion-title>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content>\n      <ion-list>\n        <ion-item>\n          <ion-icon  name=\"person-add-outline\" slot=\"start\"></ion-icon>\n          <button ion-button outline block   expand=\"block\" routerLink=\"/add-patient\" routerDirection=\"root\">Add Patient Record</button>\n        </ion-item>\n        <ion-item>\n          <ion-icon name=\"trash\" slot=\"start\"></ion-icon>\n          <button ion-button outline expand=\"block\" routerLink=\"\" routerDirection=\"root\">Delete Account</button>\n        </ion-item>\n        <ion-item>\n          <ion-icon  name=\"log-out\" slot=\"start\"></ion-icon>\n          <button ion-button outline block   expand=\"block\" routerLink=\"/login\" routerDirection=\"root\">Logout</button>\n        </ion-item>\n        <ion-item>\n          <ion-icon name=\"settings\" slot=\"start\"></ion-icon>\n          <button ion-button outline expand=\"block\" routerLink=\"/account-settings\" routerDirection=\"root\">Settings</button>\n        </ion-item>\n      </ion-list>\n    </ion-content>\n  </ion-menu>\n\n  \n\n  <div class=\"ion-page\" id=\"main-content\" >\n    <ion-header class=\"header\">\n      <ion-toolbar>\n        <ion-buttons slot=\"start\">\n          <ion-menu-button color=\"secondary\"></ion-menu-button>\n        </ion-buttons>\n        <ion-title color=\"secondary\" > Account Settings </ion-title>\n      </ion-toolbar>\n    </ion-header>\n\n\n\n\n    \n    <ion-content >\n      <form>\n        <ion-grid>\n          <ion-row color=\"secondary\" justify-content-center>\n              <div padding>\n                <br>\n                <ion-label class=\"title\"> Email Address </ion-label>\n                <ion-item> \n                  <ion-input name=\"email\" type=\"email\" placeholder=\"your@email.com\" ngModel required></ion-input> \n                </ion-item>\n                <br>\n    \n                <ion-label class=\"title\">Phone Number </ion-label>\n                <ion-item> \n                  <ion-input name=\"Phone Number\" type=\"number\" placeholder=\"Phone number\" ngModel required></ion-input> \n                </ion-item>\n                <br>\n    \n                <ion-label class=\"title\"> Current Hospital </ion-label> \n                <ion-item> \n                  <ion-input name=\"Current Hospital\" type=\"text\" placeholder=\"current hospital\" ngModel required></ion-input> \n                </ion-item> \n                <br>\n    \n                <ion-label class=\"title\"> Password </ion-label>\n                <ion-item> \n                  <ion-input name=\"password\" type=\"password\" placeholder=\"Password\" ngModel required></ion-input> \n                </ion-item>\n                <br>\n    \n                <ion-label class=\"title\"> Confirm Password </ion-label>\n                <ion-item> \n                  <ion-input name=\"confirm\" type=\"password\" placeholder=\"Conform Password\" ngModel required></ion-input> \n                </ion-item>\n                <br>\n                \n              </div>\n              <ion-button class=\"list\" color=\"secondary\" type=\"button\">  REGISTER  </ion-button> \n          </ion-row>\n        </ion-grid>\n      </form>\n      \n    </ion-content>\n\n\n\n\n    <ion-footer>\n\n      <ion-toolbar>\n        <ion-buttons slot=\"start\">\n          <ion-button color=\"secondary\" expand=\"block\" routerLink=\"/home\" routerDirection=\"root\">\n            <ion-icon slot=\"icon-only\" name=\"arrow-back\"   class=\"submit\" type=\"submit\" expand=\"block\" routerLink=\"/home\" routerDirection=\"root\"></ion-icon>\n          </ion-button>\n        </ion-buttons>\n      \n\n\n        <ion-buttons slot=\"end\">\n          <ion-button color=\"secondary\"  class=\"login\" expand=\"block\" routerLink=\"/add-patient\" routerDirection=\"root\">\n            <ion-icon slot=\"icon-only\" name=\"add\"    class=\"submit\" type=\"submit\" expand=\"block\" routerLink=\"/add-patient\" routerDirection=\"root\"> </ion-icon>\n          </ion-button>\n        </ion-buttons>\n      </ion-toolbar>\n    </ion-footer>\n  </div>\n</ion-app>\n");

/***/ }),

/***/ "./src/app/account-settings/account-settings-routing.module.ts":
/*!*********************************************************************!*\
  !*** ./src/app/account-settings/account-settings-routing.module.ts ***!
  \*********************************************************************/
/*! exports provided: AccountSettingsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountSettingsPageRoutingModule", function() { return AccountSettingsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _account_settings_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./account-settings.page */ "./src/app/account-settings/account-settings.page.ts");




const routes = [
    {
        path: '',
        component: _account_settings_page__WEBPACK_IMPORTED_MODULE_3__["AccountSettingsPage"]
    }
];
let AccountSettingsPageRoutingModule = class AccountSettingsPageRoutingModule {
};
AccountSettingsPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AccountSettingsPageRoutingModule);



/***/ }),

/***/ "./src/app/account-settings/account-settings.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/account-settings/account-settings.module.ts ***!
  \*************************************************************/
/*! exports provided: AccountSettingsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountSettingsPageModule", function() { return AccountSettingsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _account_settings_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./account-settings-routing.module */ "./src/app/account-settings/account-settings-routing.module.ts");
/* harmony import */ var _account_settings_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./account-settings.page */ "./src/app/account-settings/account-settings.page.ts");







let AccountSettingsPageModule = class AccountSettingsPageModule {
};
AccountSettingsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _account_settings_routing_module__WEBPACK_IMPORTED_MODULE_5__["AccountSettingsPageRoutingModule"]
        ],
        declarations: [_account_settings_page__WEBPACK_IMPORTED_MODULE_6__["AccountSettingsPage"]]
    })
], AccountSettingsPageModule);



/***/ }),

/***/ "./src/app/account-settings/account-settings.page.scss":
/*!*************************************************************!*\
  !*** ./src/app/account-settings/account-settings.page.scss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("button {\n  color: #3dc2ff;\n  background-color: white;\n  font-size: 16px;\n}\n\n.title {\n  font-weight: bold;\n  margin-left: 5%;\n  color: #3dc2ff;\n  font-size: 16px;\n}\n\n.list {\n  width: 85%;\n  margin-left: 10%;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWNjb3VudC1zZXR0aW5ncy9DOlxcVXNlcnNcXGRpbmlzXFxEZXNrdG9wXFxTREdQXFxmb3JtXFxOZXcgZm9sZGVyXFxBcHA0XFxteUFwcC9zcmNcXGFwcFxcYWNjb3VudC1zZXR0aW5nc1xcYWNjb3VudC1zZXR0aW5ncy5wYWdlLnNjc3MiLCJzcmMvYXBwL2FjY291bnQtc2V0dGluZ3MvYWNjb3VudC1zZXR0aW5ncy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxjQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0FDQ0o7O0FERUE7RUFDSSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQ0NKOztBRENBO0VBQ0ksVUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUNFSiIsImZpbGUiOiJzcmMvYXBwL2FjY291bnQtc2V0dGluZ3MvYWNjb3VudC1zZXR0aW5ncy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJidXR0b257XHJcbiAgICBjb2xvcjojM2RjMmZmO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcblxyXG59XHJcbi50aXRsZXtcclxuICAgIGZvbnQtd2VpZ2h0OmJvbGQ7XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICBjb2xvcjogIzNkYzJmZjtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICB9XHJcbi5saXN0e1xyXG4gICAgd2lkdGg6IDg1JTtcclxuICAgIG1hcmdpbi1sZWZ0OiAxMCU7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICB9IiwiYnV0dG9uIHtcbiAgY29sb3I6ICMzZGMyZmY7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbi50aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBtYXJnaW4tbGVmdDogNSU7XG4gIGNvbG9yOiAjM2RjMmZmO1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbi5saXN0IHtcbiAgd2lkdGg6IDg1JTtcbiAgbWFyZ2luLWxlZnQ6IDEwJTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59Il19 */");

/***/ }),

/***/ "./src/app/account-settings/account-settings.page.ts":
/*!***********************************************************!*\
  !*** ./src/app/account-settings/account-settings.page.ts ***!
  \***********************************************************/
/*! exports provided: AccountSettingsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AccountSettingsPage", function() { return AccountSettingsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let AccountSettingsPage = class AccountSettingsPage {
    constructor() { }
    ngOnInit() {
    }
};
AccountSettingsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-account-settings',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./account-settings.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/account-settings/account-settings.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./account-settings.page.scss */ "./src/app/account-settings/account-settings.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], AccountSettingsPage);



/***/ })

}]);
//# sourceMappingURL=account-settings-account-settings-module-es2015.js.map