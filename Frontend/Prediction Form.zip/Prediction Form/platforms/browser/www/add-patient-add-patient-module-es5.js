function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["add-patient-add-patient-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/add-patient/add-patient.page.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/add-patient/add-patient.page.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAddPatientAddPatientPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-app>\r\n    <ion-menu side=\"start\" content-id=\"main-content\">\r\n      <ion-header>\r\n        <ion-toolbar translucent>\r\n          <ion-title>Menu</ion-title>\r\n        </ion-toolbar>\r\n      </ion-header>\r\n      <ion-content>\r\n        <ion-list>\r\n          <ion-list>\r\n            <ion-item>\r\n              <ion-icon  name=\"person-add-outline\" slot=\"start\"></ion-icon>\r\n              <button ion-button outline block   expand=\"block\" routerLink=\"/add-patient\" routerDirection=\"root\">Add Patient Record</button>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-icon name=\"trash\" slot=\"start\"></ion-icon>\r\n              <button ion-button outline expand=\"block\" routerLink=\"\" routerDirection=\"root\">Delete Account</button>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-icon  name=\"log-out\" slot=\"start\"></ion-icon>\r\n              <button ion-button outline block   expand=\"block\" routerLink=\"/login\" routerDirection=\"root\">Logout</button>\r\n            </ion-item>\r\n            <ion-item>\r\n              <ion-icon name=\"settings\" slot=\"start\"></ion-icon>\r\n              <button ion-button outline expand=\"block\" routerLink=\"/account-settings\" routerDirection=\"root\">Settings</button>\r\n            </ion-item>\r\n          </ion-list>\r\n        </ion-list>\r\n      </ion-content>\r\n    </ion-menu>\r\n  \r\n    \r\n    <div class=\"ion-page\" id=\"main-content\" >\r\n      <ion-header class=\"header\">\r\n        <ion-toolbar>\r\n          <ion-buttons slot=\"start\">\r\n            <ion-menu-button color=\"secondary\"></ion-menu-button>\r\n          </ion-buttons>\r\n          <ion-title color=\"secondary\" > Add Patient Records</ion-title>\r\n        </ion-toolbar>\r\n\r\n        <ion-toolbar class=\"toolbar\">\r\n        </ion-toolbar>\r\n\r\n        <ion-toolbar class=\"toolbar\">\r\n        </ion-toolbar>\r\n\r\n\r\n\r\n      </ion-header>\r\n      <ion-content>\r\n        <br><br><br><br><br><br><br>\r\n        <form>\r\n            <ion-label>\r\n                <div class = \"title\"> NIC Number </div>\r\n                <ion-input id=\"input-nic\" class=\"select1\" placeholder=\"NIC Number\" type=\"number\"></ion-input>\r\n                </ion-label>\r\n            <br>\r\n            <ion-button color=\"danger\"  routerLink=\"/home\" routerDirection=\"root\" (click)=\"presentLoading()\">\r\n                <ion-icon slot=\"start\" name=\"close\"></ion-icon> Cancel </ion-button>\r\n            \r\n            <ion-button color=\"secondary\" id=\"add-patient\" routerLink=\"/form\" routerDirection=\"root\" type=\"submit\">  \r\n                <ion-icon slot=\"start\" name=\"add\"></ion-icon> Add </ion-button>\r\n        </form>\r\n      </ion-content>\r\n  \r\n      <ion-footer>\r\n        <ion-toolbar>\r\n          <ion-buttons slot=\"start\">\r\n            <ion-button color=\"secondary\"  class=\"login\" expand=\"block\" routerLink=\"/home\" routerDirection=\"root\">\r\n              <ion-icon slot=\"icon-only\" name=\"arrow-back\" class=\"submit\" type=\"submit\" expand=\"block\" routerLink=\"/home\" routerDirection=\"root\"></ion-icon>\r\n            </ion-button>\r\n          </ion-buttons>\r\n        </ion-toolbar>\r\n      </ion-footer>\r\n    </div>\r\n  </ion-app>\r\n  \r\n  ";
    /***/
  },

  /***/
  "./src/app/add-patient/add-patient.module.ts":
  /*!***************************************************!*\
    !*** ./src/app/add-patient/add-patient.module.ts ***!
    \***************************************************/

  /*! exports provided: AddPatientPageModule */

  /***/
  function srcAppAddPatientAddPatientModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddPatientPageModule", function () {
      return AddPatientPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _add_patient_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./add-patient.page */
    "./src/app/add-patient/add-patient.page.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var AddPatientPageModule = function AddPatientPageModule() {
      _classCallCheck(this, AddPatientPageModule);
    };

    AddPatientPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-home',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-patient.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/add-patient/add-patient.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-patient.page.scss */
      "./src/app/add-patient/add-patient.page.scss"))["default"]]
    }), Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"].forChild([{
        path: '',
        component: _add_patient_page__WEBPACK_IMPORTED_MODULE_5__["AddPatientPage"]
      }])],
      declarations: [_add_patient_page__WEBPACK_IMPORTED_MODULE_5__["AddPatientPage"]]
    })], AddPatientPageModule);
    /***/
  },

  /***/
  "./src/app/add-patient/add-patient.page.scss":
  /*!***************************************************!*\
    !*** ./src/app/add-patient/add-patient.page.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppAddPatientAddPatientPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".toolbar {\n  height: 50%;\n  text-align: center;\n  background-color: white;\n  --background: url('avata6.png') no-repeat fixed center;\n  background-size: cover;\n}\n\nimg {\n  height: 100px;\n  text-align: center;\n}\n\n.select1 {\n  color: #6a6a6b;\n  margin-left: 2%;\n  text-align: center;\n  background-color: #f5f9fd;\n  font-size: 16px;\n  height: 30px;\n}\n\nion-button {\n  width: 48%;\n}\n\nbutton {\n  color: #3dc2ff;\n  background-color: white;\n  font-size: 16px;\n}\n\n.title {\n  font-weight: bold;\n  margin-left: 5%;\n  color: #3dc2ff;\n  font-size: 16px;\n}\n\n.list {\n  width: 85%;\n  margin-left: 10%;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWRkLXBhdGllbnQvQzpcXFVzZXJzXFxkaW5pc1xcRGVza3RvcFxcU0RHUFxcZm9ybVxcTmV3IGZvbGRlclxcQXBwNFxcbXlBcHAvc3JjXFxhcHBcXGFkZC1wYXRpZW50XFxhZGQtcGF0aWVudC5wYWdlLnNjc3MiLCJzcmMvYXBwL2FkZC1wYXRpZW50L2FkZC1wYXRpZW50LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBRUEsc0RBQUE7RUFDQSxzQkFBQTtBQ0FKOztBREVBO0VBQ0ksYUFBQTtFQUNBLGtCQUFBO0FDQ0o7O0FERUE7RUFDSSxjQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtBQ0NKOztBRENFO0VBQ0ksVUFBQTtBQ0VOOztBRENFO0VBQ0UsY0FBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtBQ0VKOztBRENBO0VBQ0ksaUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7QUNFSjs7QURBQTtFQUNJLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0FDR0oiLCJmaWxlIjoic3JjL2FwcC9hZGQtcGF0aWVudC9hZGQtcGF0aWVudC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudG9vbGJhcntcclxuICAgIGhlaWdodDogNTAlO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgIFxyXG4gICAgLS1iYWNrZ3JvdW5kOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1hZ2UvYXZhdGE2LnBuZ1wiKSBuby1yZXBlYXQgZml4ZWQgY2VudGVyO1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxufVxyXG5pbWd7XHJcbiAgICBoZWlnaHQ6IDEwMHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uc2VsZWN0MXtcclxuICAgIGNvbG9yOiAgcmdiKDEwNiwgMTA2LCAxMDcpIDtcclxuICAgIG1hcmdpbi1sZWZ0OiAyJTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICByZ2IoMjQ1LCAyNDksIDI1Myk7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgfVxyXG4gIGlvbi1idXR0b257XHJcbiAgICAgIHdpZHRoOiA0OCU7XHJcbiAgfVxyXG5cclxuICBidXR0b257XHJcbiAgICBjb2xvcjojM2RjMmZmO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcblxyXG59XHJcbi50aXRsZXtcclxuICAgIGZvbnQtd2VpZ2h0OmJvbGQ7XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICBjb2xvcjogIzNkYzJmZjtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICB9XHJcbi5saXN0e1xyXG4gICAgd2lkdGg6IDg1JTtcclxuICAgIG1hcmdpbi1sZWZ0OiAxMCU7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICB9IiwiLnRvb2xiYXIge1xuICBoZWlnaHQ6IDUwJTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgLS1iYWNrZ3JvdW5kOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1hZ2UvYXZhdGE2LnBuZ1wiKSBuby1yZXBlYXQgZml4ZWQgY2VudGVyO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuXG5pbWcge1xuICBoZWlnaHQ6IDEwMHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5cbi5zZWxlY3QxIHtcbiAgY29sb3I6ICM2YTZhNmI7XG4gIG1hcmdpbi1sZWZ0OiAyJTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmOWZkO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGhlaWdodDogMzBweDtcbn1cblxuaW9uLWJ1dHRvbiB7XG4gIHdpZHRoOiA0OCU7XG59XG5cbmJ1dHRvbiB7XG4gIGNvbG9yOiAjM2RjMmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4udGl0bGUge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xuICBjb2xvcjogIzNkYzJmZjtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4ubGlzdCB7XG4gIHdpZHRoOiA4NSU7XG4gIG1hcmdpbi1sZWZ0OiAxMCU7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/add-patient/add-patient.page.ts":
  /*!*************************************************!*\
    !*** ./src/app/add-patient/add-patient.page.ts ***!
    \*************************************************/

  /*! exports provided: AddPatientPage */

  /***/
  function srcAppAddPatientAddPatientPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AddPatientPage", function () {
      return AddPatientPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var AddPatientPage = /*#__PURE__*/function () {
      function AddPatientPage() {
        _classCallCheck(this, AddPatientPage);
      }

      _createClass(AddPatientPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }]);

      return AddPatientPage;
    }();

    AddPatientPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-add-patient',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./add-patient.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/add-patient/add-patient.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./add-patient.page.scss */
      "./src/app/add-patient/add-patient.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])], AddPatientPage);
    /***/
  }
}]);
//# sourceMappingURL=add-patient-add-patient-module-es5.js.map