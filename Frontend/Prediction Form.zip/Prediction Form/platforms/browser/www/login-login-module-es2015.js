(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n<ion-content class=\"background\">\n <img src=\"assets/image/logo.png\" alt=\"logo\">\n\n <form onsubmit=\"processForm(event)\">\n\n <ion-list class=\"list\">\n <ion-item> <ion-input required name=\"Id number\" type=\"text\" placeholder=\"Doctor ID\" oninput=\"handleDoctorId(event)\"></ion-input>  </ion-item>\n <ion-item> <ion-input required name=\"password\" type=\"text\" placeholder=\"Password\" oninput=\"handlePassword(event)\" ></ion-input></ion-item>\n </ion-list>\n <br>\n <ion-button color=\"secondary\"  expand=\"block\" routerLink=\"/home\" routerDirection=\"root\" (click)=\"presentLoading()\"> LOGIN </ion-button>\n <br>\n <button ion-button outline expand=\"block\" routerLink=\"/login\" routerDirection=\"root\"> Forget Password </button>\n <br>\n <br>\n <ion-button color=\"secondary\"  expand=\"block\" routerLink=\"/register\" routerDirection=\"root\">  Register </ion-button>\n\n  </form>\n\n</ion-content>\n</ion-app>\n");

/***/ }),

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");







const controller = document.querySelector('ion-alert-controller');
let doctorId, password;
//function processForm(event:any):void {
//  event.preventDefault();
// controller.create({
//  header: 'Login',
//  message: `Created account for: <b>${doctorId} ${password}</b>`,
//  buttons: [{
//   text: 'OK'
// }]
// }).then(alert => alert.present());
//}
// function handleDoctorId(event) {
//   doctorId = event.target.value;
//}
// function handlePassword(event) {
//  password = event.target.value;
// }
let LoginPageModule = class LoginPageModule {
    constructor() {
        this.projects = [];
    }
    nextpage() {
    }
};
LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]
                }
            ])
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], LoginPageModule);



/***/ }),

/***/ "./src/app/login/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content.background {\n  text-align: center;\n  --background: url('piv8.jpg') no-repeat fixed center;\n  background-size: cover;\n}\n\nimg {\n  margin-top: 25px;\n  width: 120px;\n}\n\n.list {\n  margin-right: 10%;\n  margin-left: 10%;\n  font-size: 14px;\n  text-align: center;\n  color: #3dc2ff;\n  background-color: transparent;\n  font-size: 10px;\n}\n\nion-button {\n  width: 80%;\n  margin-left: 10%;\n  font-weight: bold;\n}\n\ndiv {\n  text-align: center;\n  text-decoration: underline;\n  margin-top: 20px;\n  color: #3dc2ff;\n  font-size: 14px;\n}\n\nbutton {\n  color: #3dc2ff;\n  background-color: transparent;\n  font-size: 16px;\n  text-decoration: underline;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vQzpcXFVzZXJzXFxkaW5pc1xcRGVza3RvcFxcU0RHUFxcZm9ybVxcTmV3IGZvbGRlclxcQXBwNFxcbXlBcHAvc3JjXFxhcHBcXGxvZ2luXFxsb2dpbi5wYWdlLnNjc3MiLCJzcmMvYXBwL2xvZ2luL2xvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUNFLGtCQUFBO0VBQ0Esb0RBQUE7RUFDQSxzQkFBQTtBQ0FGOztBREdBO0VBQ0UsZ0JBQUE7RUFDQSxZQUFBO0FDQUY7O0FER0E7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLDZCQUFBO0VBQ0EsZUFBQTtBQ0FGOztBREdBO0VBQ0UsVUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUNBRjs7QURJQTtFQUNFLGtCQUFBO0VBQ0EsMEJBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FDREY7O0FER0E7RUFDRSxjQUFBO0VBQ0EsNkJBQUE7RUFDQSxlQUFBO0VBQ0EsMEJBQUE7QUNBRiIsImZpbGUiOiJzcmMvYXBwL2xvZ2luL2xvZ2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuaW9uLWNvbnRlbnQuYmFja2dyb3VuZCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgLS1iYWNrZ3JvdW5kOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1hZ2UvcGl2OC5qcGdcIikgbm8tcmVwZWF0IGZpeGVkIGNlbnRlcjtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcbn1cblxuaW1ne1xuICBtYXJnaW4tdG9wOiAyNXB4O1xuICB3aWR0aDogMTIwcHg7XG59XG5cbi5saXN0e1xuICBtYXJnaW4tcmlnaHQ6MTAlO1xuICBtYXJnaW4tbGVmdDogMTAlO1xuICBmb250LXNpemU6MTRweDtcbiAgdGV4dC1hbGlnbjpjZW50ZXI7XG4gIGNvbG9yOiAjM2RjMmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgZm9udC1zaXplOiAxMHB4O1xufVxuXG5pb24tYnV0dG9ue1xuICB3aWR0aDogODAlO1xuICBtYXJnaW4tbGVmdDogMTAlO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgXG59XG5cbmRpdntcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgbWFyZ2luLXRvcDogMjBweDtcbiAgY29sb3I6IzNkYzJmZjtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuYnV0dG9ue1xuICBjb2xvcjojM2RjMmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOnRyYW5zcGFyZW50O1xuICBmb250LXNpemU6IDE2cHg7XG4gIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xuXG59IiwiaW9uLWNvbnRlbnQuYmFja2dyb3VuZCB7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgLS1iYWNrZ3JvdW5kOiB1cmwoXCIuLi8uLi9hc3NldHMvaW1hZ2UvcGl2OC5qcGdcIikgbm8tcmVwZWF0IGZpeGVkIGNlbnRlcjtcbiAgYmFja2dyb3VuZC1zaXplOiBjb3Zlcjtcbn1cblxuaW1nIHtcbiAgbWFyZ2luLXRvcDogMjVweDtcbiAgd2lkdGg6IDEyMHB4O1xufVxuXG4ubGlzdCB7XG4gIG1hcmdpbi1yaWdodDogMTAlO1xuICBtYXJnaW4tbGVmdDogMTAlO1xuICBmb250LXNpemU6IDE0cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgY29sb3I6ICMzZGMyZmY7XG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICBmb250LXNpemU6IDEwcHg7XG59XG5cbmlvbi1idXR0b24ge1xuICB3aWR0aDogODAlO1xuICBtYXJnaW4tbGVmdDogMTAlO1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cblxuZGl2IHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcbiAgbWFyZ2luLXRvcDogMjBweDtcbiAgY29sb3I6ICMzZGMyZmY7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cblxuYnV0dG9uIHtcbiAgY29sb3I6ICMzZGMyZmY7XG4gIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xuICBmb250LXNpemU6IDE2cHg7XG4gIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/login/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");



let LoginPage = class LoginPage {
    constructor(loadingCtrl) {
        this.loadingCtrl = loadingCtrl;
    }
    presentLoading() {
        this.loadingCtrl.create({
            message: 'Please wait...',
            duration: 3000,
        }); //.present();
    }
};
LoginPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'login-page',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./login.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]])
], LoginPage);



/***/ })

}]);
//# sourceMappingURL=login-login-module-es2015.js.map