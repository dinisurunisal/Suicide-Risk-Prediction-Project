(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["form-form-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/form/form.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/form/form.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n  <ion-menu side=\"start\" content-id=\"main-content\">\n    <ion-header>\n      <ion-toolbar translucent>\n        <ion-title class=\"title\">Menu</ion-title>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content>\n      <ion-list>\n        <ion-item>\n          <ion-icon  name=\"person-add-outline\" slot=\"start\"></ion-icon>\n          <button ion-button outline block  expand=\"block\" routerLink=\"/add-patient\" routerDirection=\"root\">Add Patient Record</button>\n        </ion-item>\n        <ion-item>\n          <ion-icon name=\"trash\" slot=\"start\"></ion-icon>\n          <button ion-button outline expand=\"block\" routerLink=\"\" routerDirection=\"root\">Delete Account</button>\n        </ion-item>\n        <ion-item>\n          <ion-icon  name=\"log-out\" slot=\"start\"></ion-icon>\n          <button ion-button outline block  expand=\"block\" routerLink=\"/login\" routerDirection=\"root\">Logout</button>\n        </ion-item>\n        <ion-item>\n          <ion-icon name=\"settings\" slot=\"start\"></ion-icon>\n          <button ion-button outline expand=\"block\" routerLink=\"/account-settings\" routerDirection=\"root\">Settings</button>\n        </ion-item>\n      </ion-list>\n    </ion-content>\n  </ion-menu>\n\n\n\n  <div class=\"ion-page\" id=\"main-content\" >\n    <ion-header class=\"header\">\n      <ion-toolbar>\n        <ion-buttons slot=\"start\">\n          <ion-menu-button color=\"secondary\"></ion-menu-button>\n        </ion-buttons>\n        <ion-title color=\"secondary\"> Prediction Form </ion-title>\n      </ion-toolbar>\n    </ion-header>\n\n\n\n    <ion-content class=\"head1\">\n      <br>\n\n      <ion-label class = \"\">\n       <div class = \"title\"> NIC </div>\n       <ion-textarea class=\"select1\" size=\"26\" placeholder=\"NIC Number\"></ion-textarea>\n    </ion-label>\n    <br>\n    <br>\n\n\n    <ion-label class = \"\">\n     <div class = \"title\"> Doctor ID </div>\n      <ion-textarea class=\"select1\" size=\"26\" placeholder=\"Doctor ID\"></ion-textarea>\n    </ion-label>\n    <br>\n    <br>\n\n\n     <ion-label class = \"\">\n         <div class = \"title\"> Age </div>\n         <ion-textarea class=\"select1\"  size=\"26\" ngDefaultControl [(ngModel)]=\"Age\" placeholder=\"Age\" ></ion-textarea>\n    </ion-label>\n    <br>\n    <br>\n\n   <ion-label class = \"\">\n     <div class=\"title\"> Date </div>\n      <ion-input name=\"DOB\" type=\"date\" placeholder=\"xx/xx/xxx\" ngModel required></ion-input> \n  </ion-label>\n  <br>\n \n    <ion-list>\n      <ion-radio-group ngDefaultControl [(ngModel)]=\"Gender\">\n        <ion-list-header>\n          <ion-label  class=\"title\"> Gender </ion-label>\n        </ion-list-header>\n    \n        <ion-item>\n          <ion-label >Male</ion-label>\n          <ion-radio slot=\"start\" value=\"0\"></ion-radio>\n        </ion-item>\n    \n        <ion-item>\n          <ion-label >Female</ion-label>\n          <ion-radio value=\"1\" slot=\"start\"></ion-radio>\n        </ion-item>\n      </ion-radio-group>\n    </ion-list>\n    <br>\n    <br>\n\n    <ion-label class = \"\">\n       <div class = \"title\"> Religion </div>\n     \n       <ion-select ngDefaultControl [(ngModel)]=\"Religon\" class=\"select1\">\n          <ion-select-option selected value=\"0\"> Buddhist </ion-select-option>\n          <ion-select-option value=\"1\"> Christian </ion-select-option>\n          <ion-select-option value=\"2\"> Hindu </ion-select-option>\n          <ion-select-option value=\"3\"> Islam </ion-select-option>\n          <ion-select-option value=\"4\"> Other </ion-select-option>\n       </ion-select>\n    </ion-label>\n    <br>\n    <br>\n\n \n    <ion-label>\n       <div class = \"title\">  Race </div>\n     \n       <ion-select ngDefaultControl [(ngModel)]=\"Race\" class=\"select1\">\n        <ion-select-option selected value=\"0\"> Burger </ion-select-option>\n        <ion-select-option value=\"1\"> Muslim </ion-select-option>\n        <ion-select-option value=\"2\"> Other </ion-select-option>\n        <ion-select-option value=\"3\"> Sinhalese </ion-select-option>\n        <ion-select-option value=\"4\"> Tamil </ion-select-option>\n       </ion-select>\n    </ion-label>\n    <br>\n    <br>\n\n \n    <ion-label>\n       <div class = \"title\"> Nature of Occupation </div>\n     \n       <ion-select ngDefaultControl [(ngModel)]=\"Nature_Of_Occupation\" class=\"select1\">\n        <ion-select-option value=\"0\"> White-collar workers </ion-select-option>\n        <ion-select-option value=\"1\"> Farming, fishing, and forestry workers. </ion-select-option>\n        <ion-select-option value=\"2\"> Armed Services </ion-select-option>\n        <ion-select-option value=\"3\"> Clerical & related workers </ion-select-option>\n        <ion-select-option value=\"4\"> Pensioner </ion-select-option>\n        <ion-select-option value=\"5\"> Police </ion-select-option>\n        <ion-select-option value=\"6\"> Clarical workers. </ion-select-option>\n        <ion-select-option value=\"7\"> Professional Workers. </ion-select-option>\n        <ion-select-option value=\"8\"> Sales workers </ion-select-option>\n        <ion-select-option value=\"9\"> Security Personnel </ion-select-option>\n        <ion-select-option value=\"10\"> Cooks/ Tailors/ Barbers/ etc... </ion-select-option>\n        <ion-select-option value=\"11\"> Student </ion-select-option>\n        <ion-select-option value=\"12\"> Unemployed Persons </ion-select-option>\n        <ion-select-option value=\"13\"> Workers not classfied by Occupation. </ion-select-option>\n       </ion-select>\n    </ion-label>\n    <br>\n    <br>\n\n \n    <ion-label>\n       <div class = \"title\">  Civil Status </div>\n     \n       <ion-select ngDefaultControl [(ngModel)]=\"Civil_Status\" class=\"select1\">\n          <ion-select-option value=\"0\"> Divourced </ion-select-option>\n          <ion-select-option selected value=\"1\"> Married </ion-select-option>\n          <ion-select-option value=\"2\"> Unmarried </ion-select-option>\n          <ion-select-option value=\"3\"> Widow </ion-select-option>\n       </ion-select>\n    </ion-label>\n    <br>\n    <br>\n\n \n    <ion-label>\n       <div class = \"title\">  Education Level </div>\n     \n       <ion-select ngDefaultControl [(ngModel)]=\"Education_Level\" class=\"select1\">\n          <ion-select-option selected value=\"0\"> From Grade 1 to 7 </ion-select-option>\n          <ion-select-option value=\"4\"> Passed Grade 8 </ion-select-option>\n          <ion-select-option value=\"3\"> Passed G.C.E (O/L) </ion-select-option>\n          <ion-select-option value=\"2\"> Passed G.C.E (A/L) </ion-select-option>\n          <ion-select-option value=\"6\"> University Degree or above </ion-select-option>\n          <ion-select-option value=\"1\"> Other </ion-select-option>\n       </ion-select>\n    </ion-label>\n    <br>\n    <br>\n\n \n    <ion-label>\n       <div class = \"title\"> Reason </div>\n\n       <ion-select ngDefaultControl [(ngModel)]=\"Reason\" class=\"select1\">\n          <ion-select-option value=\"0\"> Addiction to narcotic drugs </ion-select-option>\n          <ion-select-option selected value=\"1\"> Due to death parents/relations </ion-select-option>\n          <ion-select-option value=\"2\"> Chronic diseases & Physical disabilities </ion-select-option>\n          <ion-select-option value=\"3\"> Economic problems </ion-select-option>\n          <ion-select-option value=\"4\"> Employment problems </ion-select-option>\n          <ion-select-option value=\"5\"> Failure at the examination </ion-select-option>\n          <ion-select-option value=\"6\"> Harrasment by a family member </ion-select-option>\n          <ion-select-option value=\"7\"> Ill-treatment by the children </ion-select-option>\n          <ion-select-option value=\"8\"> Loss of property </ion-select-option>\n          <ion-select-option value=\"9\"> Mental Disorders </ion-select-option>\n          <ion-select-option value=\"10\"> Natural Death </ion-select-option>\n          <ion-select-option value=\"11\"> Other Reasons </ion-select-option>\n          <ion-select-option value=\"12\"> Problems caused with the elders </ion-select-option>\n          <ion-select-option value=\"13\"> Sexual incapacity </ion-select-option>\n          <ion-select-option value=\"14\"> Problems with love affairs </ion-select-option>\n       </ion-select>\n    </ion-label>\n    <br>\n    <br>\n\n   \n    <ion-list>\n      <ion-radio-group ngDefaultControl [(ngModel)]=\"Lifetime_Psychiatric_Hospitalizations\">\n        <ion-list-header>\n          <ion-label class=\"title\">Lifetime Psychiatric Hospitalizations </ion-label>\n        </ion-list-header>\n    \n        <ion-item>\n          <ion-label>Haven't</ion-label>\n          <ion-radio slot=\"start\" value=\"0\"></ion-radio>\n        </ion-item>\n    \n        <ion-item>\n          <ion-label >Have</ion-label>\n          <ion-radio slot=\"start\" value=\"1\"></ion-radio>\n        </ion-item>\n    \n      </ion-radio-group>\n    </ion-list>\n    <ion-list>\n      <ion-radio-group  ngDefaultControl [(ngModel)]=\"Past_Suicide_Attempts\">\n        <ion-list-header>\n          <ion-label class=\"title\"> Past Suicide Attempts </ion-label>\n        </ion-list-header>\n    \n        <ion-item>\n          <ion-label>Haven't</ion-label>\n          <ion-radio slot=\"start\" value=\"0\"></ion-radio>\n        </ion-item>\n    \n        <ion-item>\n          <ion-label >Have</ion-label>\n          <ion-radio slot=\"start\" value=\"1\"></ion-radio>\n        </ion-item>\n    \n      </ion-radio-group>\n    </ion-list>\n    <ion-list>\n      <ion-radio-group  ngDefaultControl [(ngModel)]=\"Any_Suicidal_Thoughts\">\n        <ion-list-header>\n          <ion-label class=\"title\">Any suicidal thoughts mentioned </ion-label>\n        </ion-list-header>\n    \n        <ion-item>\n          <ion-label>Haven't</ion-label>\n          <ion-radio slot=\"start\" value=\"0\"></ion-radio>\n        </ion-item>\n    \n        <ion-item>\n          <ion-label >Have</ion-label>\n          <ion-radio slot=\"start\" value=\"1\"></ion-radio>\n        </ion-item>\n      \n    \n      </ion-radio-group>\n    </ion-list>\n    <ion-list>\n      <ion-radio-group  ngDefaultControl [(ngModel)]=\"Self_Injurious_Behaviour\">\n        <ion-list-header>\n          <ion-label class=\"title\"> Self Injurious Behaviour </ion-label>\n        </ion-list-header>\n    \n        <ion-item>\n          <ion-label>Haven't</ion-label>\n          <ion-radio slot=\"start\" value=\"0\"></ion-radio>\n        </ion-item>\n    \n        <ion-item>\n          <ion-label >Have</ion-label>\n          <ion-radio slot=\"start\" value=\"1\"></ion-radio>\n        </ion-item>\n      </ion-radio-group>\n    </ion-list>\n    <br>\n\n<ion-label>\n  <div class = \"title\">  Psychiatric Disorders </div>\n  \n  <ion-select ngDefaultControl [(ngModel)]=\"Psychiatric_Disorders\" class=\"select1\">\n     <ion-select-option selected value=\"0\"> BPD </ion-select-option>\n     <ion-select-option value=\"1\"> Bipolar Disorder </ion-select-option>\n     <ion-select-option value=\"2\"> Depression </ion-select-option>\n     <ion-select-option value=\"3\"> None </ion-select-option>\n     <ion-select-option value=\"4\"> Other </ion-select-option>\n     <ion-select-option value=\"5\"> PTSD </ion-select-option>\n     <ion-select-option value=\"6\"> Schizophrenia </ion-select-option>\n  </ion-select>\n</ion-label>\n<br>\n<br>\n\n\n<ion-label>\n<div class = \"title\">  Past Illnesses </div>\n\n<ion-select ngDefaultControl [(ngModel)]=\"Past_Illness\" class=\"select1\">\n   <ion-select-option selected value=\"0\"> Asthma </ion-select-option>\n   <ion-select-option value=\"1\"> COPD </ion-select-option>\n   <ion-select-option value=\"2\"> Cancer </ion-select-option>\n   <ion-select-option value=\"3\"> Chronic pain </ion-select-option>\n   <ion-select-option value=\"4\">Diabetes </ion-select-option>\n   <ion-select-option value=\"5\"> HIV/AIDS </ion-select-option>\n   <ion-select-option value=\"6\"> Heart Diseases </ion-select-option>\n   <ion-select-option value=\"7\"> Kidney Disease </ion-select-option>\n   <ion-select-option value=\"8\"> Other </ion-select-option>\n   <ion-select-option value=\"9\"> Unknown </ion-select-option>\n</ion-select>\n</ion-label>\n<br>\n<br>\n\n\n<ion-label>\n<div class = \"title\">  Alcohol/ drug Consumption </div>\n\n<ion-select ngDefaultControl [(ngModel)]=\"Alcohol_drug_Consumption\" class=\"select1\">\n <ion-select-option selected value=\"0\"> Frequent </ion-select-option>\n <ion-select-option value=\"1\"> Moderate </ion-select-option>\n <ion-select-option value=\"2\"> None </ion-select-option>\n</ion-select>\n</ion-label>\n<br>\n\n\n<ion-list>\n  <ion-radio-group ngDefaultControl [(ngModel)]=\"Anger\">\n    <ion-list-header>\n      <ion-label  class=\"title\"> Anger</ion-label>\n    </ion-list-header>\n\n    <ion-item>\n      <ion-label>Haven't</ion-label>\n      <ion-radio slot=\"start\" value=\"0\"></ion-radio>\n    </ion-item>\n\n    <ion-item>\n      <ion-label >Have</ion-label>\n      <ion-radio slot=\"start\" value=\"1\"></ion-radio>\n    </ion-item>\n\n  </ion-radio-group>\n</ion-list>\n\n\n<ion-list>\n  <ion-radio-group ngDefaultControl [(ngModel)]=\"Sleep_Problem\">\n    <ion-list-header>\n      <ion-label  class=\"title\"> Sleep Proplems </ion-label>\n    </ion-list-header>\n\n    <ion-item>\n      <ion-label>Haven't</ion-label>\n      <ion-radio slot=\"start\" value=\"0\"></ion-radio>\n    </ion-item>\n\n    <ion-item>\n      <ion-label >Have</ion-label>\n      <ion-radio slot=\"start\" value=\"1\"></ion-radio>\n    </ion-item>\n\n  </ion-radio-group>\n</ion-list>\n\n \n<ion-list>\n  <ion-radio-group ngDefaultControl [(ngModel)]=\"Social_Iscolation\">\n    <ion-list-header>\n      <ion-label  class=\"title\">Social Iscolation </ion-label>\n    </ion-list-header>\n\n    <ion-item>\n      <ion-label>Haven't</ion-label>\n      <ion-radio slot=\"start\" value=\"0\"></ion-radio>\n    </ion-item>\n\n    <ion-item>\n      <ion-label >Have</ion-label>\n      <ion-radio slot=\"start\" value=\"1\"></ion-radio>\n    </ion-item>\n  </ion-radio-group>\n</ion-list>\n\n<ion-list>\n  <ion-radio-group ngDefaultControl [(ngModel)]=\"Sad_Weary\">\n    <ion-list-header>\n      <ion-label  class=\"title\"> Sad Weary </ion-label>\n    </ion-list-header>\n\n    <ion-item>\n      <ion-label>Haven't</ion-label>\n      <ion-radio slot=\"start\" value=\"0\"></ion-radio>\n    </ion-item>\n\n    <ion-item>\n      <ion-label >Have</ion-label>\n      <ion-radio slot=\"start\" value=\"1\"></ion-radio>\n    </ion-item>\n\n  </ion-radio-group>\n</ion-list>\n\n<ion-list>\n  <ion-radio-group ngDefaultControl [(ngModel)]=\"Humilated\">\n    <ion-list-header>\n      <ion-label  class=\"title\"> Humilated </ion-label>\n    </ion-list-header>\n\n    <ion-item>\n      <ion-label>Haven't</ion-label>\n      <ion-radio slot=\"start\" value=\"0\"></ion-radio>\n    </ion-item>\n\n    <ion-item>\n      <ion-label >Have</ion-label>\n      <ion-radio slot=\"start\" value=\"1\"></ion-radio>\n    </ion-item>\n\n  </ion-radio-group>\n</ion-list>\n<br>\n\n<ion-list>\n  <ion-button class=\"list\" color=\"secondary\" type=\"button\" (click)=\"sendPostRequest()\"  type=\"submit\" expand=\"block\" routerDirection=\"root\">  Submit  </ion-button>\n  <br>\n\n  <ion-button class=\"list\" color=\"secondary\" type=\"button\">  Reset  </ion-button>\n  <br>\n  <br>\n</ion-list>\n</ion-content>\n<ion-footer>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-button color=\"secondary\" expand=\"block\" routerLink=\"/home\" routerDirection=\"root\">\n        <ion-icon slot=\"icon-only\" name=\"arrow-back\"  class=\"submit\" type=\"submit\" expand=\"block\" routerLink=\"/login\" routerDirection=\"root\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-footer>\n</div>\n</ion-app>");

/***/ }),

/***/ "./src/app/form/form-routing.module.ts":
/*!*********************************************!*\
  !*** ./src/app/form/form-routing.module.ts ***!
  \*********************************************/
/*! exports provided: FormPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FormPageRoutingModule", function() { return FormPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _form_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./form.page */ "./src/app/form/form.page.ts");




const routes = [
    {
        path: '',
        component: _form_page__WEBPACK_IMPORTED_MODULE_3__["FormPage"]
    }
];
let FormPageRoutingModule = class FormPageRoutingModule {
};
FormPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], FormPageRoutingModule);



/***/ }),

/***/ "./src/app/form/form.module.ts":
/*!*************************************!*\
  !*** ./src/app/form/form.module.ts ***!
  \*************************************/
/*! exports provided: FormPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FormPageModule", function() { return FormPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _form_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./form-routing.module */ "./src/app/form/form-routing.module.ts");
/* harmony import */ var _form_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./form.page */ "./src/app/form/form.page.ts");







let FormPageModule = class FormPageModule {
};
FormPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _form_routing_module__WEBPACK_IMPORTED_MODULE_5__["FormPageRoutingModule"]
        ],
        declarations: [_form_page__WEBPACK_IMPORTED_MODULE_6__["FormPage"]]
    })
], FormPageModule);



/***/ }),

/***/ "./src/app/form/form.page.scss":
/*!*************************************!*\
  !*** ./src/app/form/form.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".head1 {\n  text-align: left;\n  color: #3dc2ff;\n  font-weight: strong;\n  border: groove;\n  border-width: 10px;\n  border-color: lightblue;\n  border-radius: 0.1em;\n  box-shadow: 6px 6px #3dc2ff;\n}\n\n.select {\n  width: 98% !important;\n  max-width: 98% !important;\n  height: 35px;\n  text-align: center;\n  font-size: 16px;\n}\n\nion-content ion-toolbar {\n  --background: translucent;\n}\n\n.list {\n  width: 85%;\n  margin-left: 10%;\n  font-weight: bold;\n}\n\n.title {\n  font-weight: bold;\n  margin-left: 5%;\n  color: #3dc2ff;\n  font-size: 16px;\n}\n\n.select1 {\n  color: #6a6a6b;\n  margin-left: 2%;\n  text-align: center;\n  background-color: #f5f9fd;\n  font-size: 16px;\n  height: 30px;\n}\n\nbutton {\n  color: #3dc2ff;\n  background-color: white;\n  font-size: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm9ybS9DOlxcVXNlcnNcXGRpbmlzXFxEZXNrdG9wXFxTREdQXFxmb3JtXFxOZXcgZm9sZGVyXFxBcHA0XFxteUFwcC9zcmNcXGFwcFxcZm9ybVxcZm9ybS5wYWdlLnNjc3MiLCJzcmMvYXBwL2Zvcm0vZm9ybS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxtQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0Esb0JBQUE7RUFDQSwyQkFBQTtBQ0FKOztBREdFO0VBQ0UscUJBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUNBSjs7QURHRTtFQUNFLHlCQUFBO0FDQUo7O0FERUU7RUFDRSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQ0NKOztBRENFO0VBQ0UsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGVBQUE7QUNFSjs7QURBRTtFQUNFLGNBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0FDR0o7O0FEREU7RUFDRSxjQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0FDSUoiLCJmaWxlIjoic3JjL2FwcC9mb3JtL2Zvcm0ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbiAgLmhlYWQxe1xyXG4gICAgdGV4dC1hbGlnbjpsZWZ0O1xyXG4gICAgY29sb3I6ICMzZGMyZmY7XHJcbiAgICBmb250LXdlaWdodDpzdHJvbmc7XHJcbiAgICBib3JkZXI6Z3Jvb3ZlO1xyXG4gICAgYm9yZGVyLXdpZHRoIDoxMHB4O1xyXG4gICAgYm9yZGVyLWNvbG9yIDpsaWdodGJsdWU7XHJcbiAgICBib3JkZXItcmFkaXVzOi4xMGVtO1xyXG4gICAgYm94LXNoYWRvdzogNnB4IDZweCAjM2RjMmZmO1xyXG4gIH1cclxuXHJcbiAgLnNlbGVjdHtcclxuICAgIHdpZHRoOiA5OCUgIWltcG9ydGFudDtcclxuICAgIG1heC13aWR0aDogOTglICFpbXBvcnRhbnQ7XHJcbiAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICAvL2ZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIH1cclxuICBpb24tY29udGVudCBpb24tdG9vbGJhciB7XHJcbiAgICAtLWJhY2tncm91bmQ6IHRyYW5zbHVjZW50O1xyXG4gIH1cclxuICAubGlzdHtcclxuICAgIHdpZHRoOiA4NSU7XHJcbiAgICBtYXJnaW4tbGVmdDogMTAlO1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgfVxyXG4gIC50aXRsZXtcclxuICAgIGZvbnQtd2VpZ2h0OmJvbGQ7XHJcbiAgICBtYXJnaW4tbGVmdDogNSU7XHJcbiAgICBjb2xvcjogIzNkYzJmZjtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICB9XHJcbiAgLnNlbGVjdDF7XHJcbiAgICBjb2xvcjogIHJnYigxMDYsIDEwNiwgMTA3KSA7XHJcbiAgICBtYXJnaW4tbGVmdDogMiU7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAgcmdiKDI0NSwgMjQ5LCAyNTMpO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgaGVpZ2h0OiAzMHB4O1xyXG4gIH1cclxuICBidXR0b257XHJcbiAgICBjb2xvcjojM2RjMmZmO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcblxyXG59IiwiLmhlYWQxIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY29sb3I6ICMzZGMyZmY7XG4gIGZvbnQtd2VpZ2h0OiBzdHJvbmc7XG4gIGJvcmRlcjogZ3Jvb3ZlO1xuICBib3JkZXItd2lkdGg6IDEwcHg7XG4gIGJvcmRlci1jb2xvcjogbGlnaHRibHVlO1xuICBib3JkZXItcmFkaXVzOiAwLjFlbTtcbiAgYm94LXNoYWRvdzogNnB4IDZweCAjM2RjMmZmO1xufVxuXG4uc2VsZWN0IHtcbiAgd2lkdGg6IDk4JSAhaW1wb3J0YW50O1xuICBtYXgtd2lkdGg6IDk4JSAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDM1cHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG5pb24tY29udGVudCBpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNsdWNlbnQ7XG59XG5cbi5saXN0IHtcbiAgd2lkdGg6IDg1JTtcbiAgbWFyZ2luLWxlZnQ6IDEwJTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbi50aXRsZSB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBtYXJnaW4tbGVmdDogNSU7XG4gIGNvbG9yOiAjM2RjMmZmO1xuICBmb250LXNpemU6IDE2cHg7XG59XG5cbi5zZWxlY3QxIHtcbiAgY29sb3I6ICM2YTZhNmI7XG4gIG1hcmdpbi1sZWZ0OiAyJTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjVmOWZkO1xuICBmb250LXNpemU6IDE2cHg7XG4gIGhlaWdodDogMzBweDtcbn1cblxuYnV0dG9uIHtcbiAgY29sb3I6ICMzZGMyZmY7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBmb250LXNpemU6IDE2cHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/form/form.page.ts":
/*!***********************************!*\
  !*** ./src/app/form/form.page.ts ***!
  \***********************************/
/*! exports provided: FormPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FormPage", function() { return FormPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm2015/http.js");



let FormPage = class FormPage {
    constructor(http) {
        this.http = http;
    }
    ngOnInit() { }
    sendPostRequest() {
        const httpOptions = {
            headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': 'my-auth-token'
            })
        };
        let postData = {
            Age: this.Age,
            Gender: this.Gender,
            Religon: this.Religon,
            Race: this.Race,
            Nature_Of_Occupation: this.Nature_Of_Occupation,
            Civil_Status: this.Civil_Status,
            Education_Level: this.Education_Level,
            Reason: this.Reason,
            Lifetime_Psychiatric_Hospitalizations: this.Lifetime_Psychiatric_Hospitalizations,
            Past_Suicide_Attempts: this.Past_Suicide_Attempts,
            Any_suicidal_thoughts_mentioned: this.Any_Suicidal_Thoughts,
            Self_Injurious_Behaviour: this.Self_Injurious_Behaviour,
            Psychiatric_Disorders: this.Psychiatric_Disorders,
            Past_Illnesses: this.Past_Illness,
            Alcohol_drug_Consumption: this.Alcohol_drug_Consumption,
            Anger: this.Anger,
            Sleep_Problem: this.Sleep_Problem,
            Social_Iscolation: this.Social_Iscolation,
            Sad_Weary: this.Sad_Weary,
            Humilated: this.Humilated,
        };
        this.http.post("http://localhost:8080/prediction", JSON.stringify(postData), httpOptions)
            .subscribe(data => {
            console.log(data['_body']);
            console.log(JSON.stringify(postData));
        }, error => {
            console.log(error);
            console.log(JSON.stringify(postData));
        });
    }
};
FormPage.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
FormPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-form',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./form.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/form/form.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./form.page.scss */ "./src/app/form/form.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]])
], FormPage);

//ionic cordova run browser


/***/ })

}]);
//# sourceMappingURL=form-form-module-es2015.js.map