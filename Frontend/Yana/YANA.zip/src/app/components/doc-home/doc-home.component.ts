import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastController, LoadingController } from '@ionic/angular';
import { UserService } from 'src/app/services/user.service';
import * as jwt_decode from 'jwt-decode';

@Component({
  selector: 'app-doc-home',
  templateUrl: './doc-home.component.html',
  styleUrls: ['./doc-home.component.scss'],
})
export class DocHomeComponent implements OnInit {
  patients = [];
  tempPatients = [];
  searchKeyword = '';

  constructor(private router: Router,
    private route: ActivatedRoute,
    public toastController: ToastController,
    public loadingController: LoadingController,
    private userService: UserService) {
    this.getAllPatients();
  }

  ngOnInit() { }
  // searchPatients(ev: any) {
  //   this.patients = [];
  //   for (let i = 0; i < this.tempPatients.length; i++) {
  //     if (this.tempPatients[i]['NIC'].includes(this.searchKeyword)) {
  //       this.patients.push(this.tempPatients[i]);
  //     }
  //   }
  //   if (this.searchKeyword && this.searchKeyword.trim() == '') {
  //     this.patients = this.tempPatients;
  //   }
  // }


  searchPatients(ev: any) {
    this.patients = [];
    let val = ev.target.value;

    console.log(this.patients);

    if (val && val.trim() != '') {
      this.patients = this.patients.filter((patient) => {
        console.log(patient);
        for (let i = 0; i < this.tempPatients.length; i++) {
          if (this.tempPatients[i]['NIC'].includes(val)) {
            this.patients.push(this.tempPatients[i]);
          }
        }
      });
    }
    else {
      this.patients = this.tempPatients;
    }

  }

  getAllPatients() {
    let docID = this.getDecodedAccessToken(localStorage.getItem('token'))["user_id"];

    if (docID != null) {
      this.userService.getAllPatients(docID).subscribe(success => {
        if (success['rows'].length > 0) {
          for (let i = 0; i < success['rows'].length; i++) {
            this.patients.push(success['rows'][i]);
            this.tempPatients.push(success['rows'][i]);
          }
          console.log(this.patients);
        }
      }, error => {
        console.log(error);
      });
    } else {
      console.log("Error in Session please log in again");
      this.router.navigate(['./signin']);
    }

  }

  getDecodedAccessToken(token: string): any {
    try {
      return jwt_decode(token);
    } catch (Error) {
      return null;
    }
  }

  getPatientRecord(patientID) {
    this.router.navigate(['./patientHome'], { queryParams: { doc_id: this.getDecodedAccessToken(localStorage.getItem('token'))["user_id"], patient_id: patientID } });
  }
}
