import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { ToastController, LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
})
export class ForgotPasswordComponent implements OnInit {
  email = '';
  token = '';
  emailSuccess = false;
  constructor(private router: Router,
              private route: ActivatedRoute,
              public toastController: ToastController,
              public loadingController: LoadingController,
              private userService: UserService) { }

  ngOnInit() { }

  login() {
    this.router.navigate(['./signin']);
  }
  sendEmail() {
    this.userService.forgetPassword(this.email).subscribe(data => {
      this.presentToast('Successfully send the mail', 2000);
      this.emailSuccess = true;
    }, error => {
      // tslint:disable-next-line:no-string-literal
      if ( error['status'] === 404) {
        this.presentToast('Error Connecting to Server', 2000);
      // tslint:disable-next-line:no-string-literal
      } else if (error['status'] === 401) {
        this.presentToast('Invalid Email address!', 2000);
      }
    });
  }
  async presentToast(msg, dur) {
    const toast = await this.toastController.create({
      message: msg,
      duration: dur,
      buttons: [
        {
          text: 'Close',
          role: 'cancel'
        }
      ]
    });
    toast.present();
    return toast.onDidDismiss();
  }
}
