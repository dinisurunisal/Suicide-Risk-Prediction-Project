import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastController, LoadingController } from '@ionic/angular';
import { UserService } from 'src/app/services/user.service';
import * as jwt_decode from 'jwt-decode';

@Component({
  selector: 'app-patient-home',
  templateUrl: './patient-home.component.html',
  styleUrls: ['./patient-home.component.scss'],
})
export class PatientHomeComponent implements OnInit {
  docId;
  patientId;
  recordId;
  patientRecords = [];
  searchKeyword = '';
  isSearchBarOpened = false;

  constructor(private router: Router,
    private route: ActivatedRoute,
    public toastController: ToastController,
    public loadingController: LoadingController,
    private userService: UserService) {
    route.queryParams.subscribe((data: any) => {
      if (data) {
        this.docId = data.doc_id;
        this.patientId = data.patient_id;
      } else {
        this.docId = null;
        this.patientId = null;
      }
    });
  }

  ngOnInit() {
    this.userService.getPatientRecords(this.docId, this.patientId).subscribe(success => {
      if (success['rows'].length > 0) {
        for (let i = 0; i < success['rows'].length; i++) {
          this.patientRecords.push(success['rows'][i]);
        }
        console.log(this.patientRecords);
      }
    }, error => {
      this.presentToast('No Records Yet', 2000);
      console.log(error);
    });
  }

  addPatientRecord() {

  }
  async presentToast(msg, dur) {
    const toast = await this.toastController.create({
      message: msg,
      duration: dur,
      buttons: [
        {
          text: 'Close',
          role: 'cancel'
        }
      ]
    });
    toast.present();
    return toast.onDidDismiss();
  }


  getDecodedAccessToken(token: string): any {
    try {
      return jwt_decode(token);
    } catch (Error) {
      return null;
    }
  }



  getPatientRecordsDetails(recordId) {
    this.router.navigate(['./recordHome'], { queryParams: { doc_id: this.getDecodedAccessToken(localStorage.getItem('token'))["user_id"], recordId: recordId } });
  }

}
