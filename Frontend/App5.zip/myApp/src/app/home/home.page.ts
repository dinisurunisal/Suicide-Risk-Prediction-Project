import { Component, OnInit } from '@angular/core';
import { Patient } from './home.model';
import { HomeService } from './home.service';
//import { AngularFirestore } from '@angular/fire/firestore'


@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
  public goalList: any[];
  public loadedGoalList: any[];
  patients: Patient[];


  constructor(
    private patientsService: HomeService,
    //private firestonne: AngularFirestore
    ){}
  

  ngOnInit() {
   this.patients = this.patientsService.gellAllPatients();
  }

}
