import { Component, OnInit } from '@angular/core';
import { HttpClient ,HttpHeaders} from '@angular/common/http';
import { map, finalize } from 'rxjs/operators';
import { HTTP } from '@ionic-native/http/ngx';
import { Platform, LoadingController } from '@ionic/angular';
import { from } from 'rxjs'; 





@Component({
  selector: 'app-form',
  templateUrl: './form.page.html',
  styleUrls: ['./form.page.scss'],
})
export class FormPage implements OnInit {

  Age: String;
  Gender: String;
  Religon: String;
  Race: String;
  Nature_Of_Occupation: String;
  Civil_Status: String;
  Education_Level: String;
  Reason: String;
  Lifetime_Psychiatric_Hospitalizations: String;
  Past_Suicide_Attempts: String;
  Any_Suicidal_Thoughts: String;
  Self_Injurious_Behaviour: String;
  Psychiatric_Disorders: String;
  Past_Illness: String;
  Alcohol_drug_Consumption: String;
  Anger: String;
  Sleep_Problem: String;
  Social_Iscolation: String;
  Sad_Weary: String;
  Humilated: String;

  constructor(public http: HttpClient) { }

  ngOnInit() {
   
      }
      sendPostRequest() {

        const httpOptions = {
          headers: new HttpHeaders({
          'Accept': 'application/json',
          'Content-Type':  'application/json',
          'Authorization': 'my-auth-token'
         })
     };
    
        let postData = {
          Age: this.Age,
          Gender: this.Gender,
          Religon: this.Religon,
          Race: this.Race,
          Nature_Of_Occupation: this.Nature_Of_Occupation,
          Civil_Status: this.Civil_Status,
          Education_Level: this.Education_Level,
          Reason: this.Reason,
          Lifetime_Psychiatric_Hospitalizations: this.Lifetime_Psychiatric_Hospitalizations,
          Past_Suicide_Attempts: this.Past_Suicide_Attempts,
          Any_suicidal_thoughts_mentioned: this.Any_Suicidal_Thoughts,
          Self_Injurious_Behaviour: this.Self_Injurious_Behaviour,
          Psychiatric_Disorders: this.Psychiatric_Disorders,
          Past_Illnesses: this.Past_Illness,
          Alcohol_drug_Consumption: this.Alcohol_drug_Consumption,
          Anger: this.Anger,
          Sleep_Problem: this.Sleep_Problem,
          Social_Iscolation: this.Social_Iscolation,
          Sad_Weary: this.Sad_Weary,
          Humilated: this.Humilated,
          }
    
        this.http.post("http://localhost:8080/prediction", JSON.stringify(postData), httpOptions)
          .subscribe(data => {
            console.log(data['_body']);
            console.log(JSON.stringify(postData))
           }, error => {
            console.log(error);
            console.log(JSON.stringify(postData))
          });
      }

    

}
