import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { HomeService } from '../home.service';
import { Patient } from '../home.model';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-patient-detail',
  templateUrl: './patient-detail.page.html',
  styleUrls: ['./patient-detail.page.scss'],
})
export class PatientDetailPage implements OnInit {


  loadedPatient: Patient;


  constructor(private activatedRoute: ActivatedRoute, 
    private HomeService: HomeService,
    private router: Router,
    private alertCtrl: AlertController
    ) {}
  


  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(paraMap => {
      if(!paraMap.has('patientId')){
        //redirect
        
        return;
      }
        const patientId = paraMap.get('patientId');
         this.loadedPatient = this.HomeService.getPatient(patientId);
    });
   
  }

  onDeletePatient(){
    this.alertCtrl.create({
      header: 'Are you sure?',
      message: 'Do you really want to delete the  Patient detalis?', 
      buttons: [{
        text:'Cancel',
        role:'cancel'
      },
      {
        text:'Delete',
        handler:() =>{
          this.HomeService.deletePatient(this.loadedPatient.title);
          this.router.navigate(['/home']);
        }
      }
     ]
    })
    .then(alertEl =>{
      alertEl.present();
    });
  }
  doConfirm(){
    this.alertCtrl.create({
      header: 'Are you sure?',
      message: 'Do you really want to Logout?', 
      buttons: [{
        text:'Cancel',
        role:'cancel'
      },
      {
        text:'Yes',
        handler:() =>{
          //this.HomeService.deletePatient(this.loadedPatient.title);
          this.router.navigate(['/login']);
        }
      }
    ]
    })
    .then(alertEl =>{
      alertEl.present();
    });
  }
}
