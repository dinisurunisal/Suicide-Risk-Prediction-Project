export interface Patient{
    id:string;
    title:string;
    
  }