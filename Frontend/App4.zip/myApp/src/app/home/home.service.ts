import { Injectable } from '@angular/core';
import { Patient } from './home.model';


@Injectable({
  providedIn: 'root'
})
export class HomeService {

  private patients: Patient [] =[
    {
      id:'p1',
      title:'996749940v',
    },
    {
      id:'p2',
      title:'20017695378',
      
    }
  ];

  constructor() { }
  gellAllPatients(){
    return[...this.patients];
  }
  
  getPatient(patientId: string){
    return {
      ...this.patients.find(patient => {
      return patient.title === patientId;
      })
    };
  }

  deletePatient(patientId:String){
    this.patients=this.patients.filter( patient =>{
      return patient.title !== patientId;
    });
  }
  logout(){
    
  }
}
