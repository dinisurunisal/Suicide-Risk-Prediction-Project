import { Component, OnInit } from '@angular/core';
import { Patient } from './home.model';
import { HomeService } from './home.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
  patients: Patient[];


  constructor(private patientsService: HomeService){}

  ngOnInit() {
   this.patients = this.patientsService.gellAllPatients();
  }

}
