import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonicModule } from '@ionic/angular';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';




import { LoginPage } from './login.page';


  const controller = document.querySelector('ion-alert-controller');
  let doctorId, password;

  //function processForm(event:any):void {
  //  event.preventDefault();
   // controller.create({
    //  header: 'Login',
    //  message: `Created account for: <b>${doctorId} ${password}</b>`,
    //  buttons: [{
     //   text: 'OK'
     // }]
   // }).then(alert => alert.present());
  //}

 // function handleDoctorId(event) {
 //   doctorId = event.target.value;
  //}

 // function handlePassword(event) {
  //  password = event.target.value;
 // }



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild([
      {
        path: '',
        component: LoginPage
      }
    ])
  ],
  declarations: [LoginPage]
})
export class LoginPageModule {
  projects: any = [];
  project: string;

  constructor() { }

  nextpage() {
   
  }
}
