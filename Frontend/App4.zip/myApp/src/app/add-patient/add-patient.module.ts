import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule, NavController } from '@ionic/angular';



import { AddPatientPage } from './add-patient.page';

import { RouterModule } from '@angular/router';

@Component({
    selector: 'app-home',
    templateUrl: 'add-patient.page.html',
    styleUrls: ['add-patient.page.scss'],
  })
  
  
  @NgModule({
    imports: [
      CommonModule,
      FormsModule,
      IonicModule,
      RouterModule.forChild([
        {
          path: '',
          component: AddPatientPage
        }
      ])
    ],
    declarations: [AddPatientPage]
  })

export class AddPatientPageModule {

}
