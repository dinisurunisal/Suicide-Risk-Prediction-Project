import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { PatientDetailsPageRoutingModule } from './patient-details-routing.module';

import { PatientDetailsPage } from './patient-details.page';
import { Routes } from '@angular/router';

const routes: Routes =[
  {
    path:'',
    component: PatientDetailsPage
  }
];
export interface Details{
  id:string;
  result:string;
}

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    PatientDetailsPageRoutingModule
  ],
  declarations: [PatientDetailsPage]
})

export class PatientDetailsPageModule {}
