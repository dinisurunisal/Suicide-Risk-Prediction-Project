import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PatientsService } from 'myApp/src/app/home/patients.service';
import { Patient } from 'myApp/src/app/home/home.module';


@Component({
  selector: 'app-patient-details',
  templateUrl: './patient-details.page.html',
  styleUrls: ['./patient-details.page.scss'],
})
export class PatientDetailsPage implements OnInit {

  loadedPatient: Patient;

  
  constructor(private activatedRoute: ActivatedRoute, 
    private PatientsService: PatientsService) { }
  

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(paraMap => {
      if(!paraMap.has('title')){
        //redirect
        return;
      }
        const title = paraMap.get('title');
        this.loadedPatient = this.PatientsService.getPatient('title');
    });
   
  }

}
