(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-patient-detail-patient-detail-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/patient-detail/patient-detail.page.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/patient-detail/patient-detail.page.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n  <ion-menu side=\"start\" content-id=\"main-content\">\n    <ion-header>\n      <ion-toolbar translucent>\n        <ion-title>Menu</ion-title>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content>\n      <ion-list>\n        <ion-item>\n          <ion-icon  name=\"person-add-outline\" slot=\"start\"></ion-icon>\n          <button ion-button outline block   expand=\"block\" routerLink=\"/add-patient\" routerDirection=\"root\">Add Patient Record</button>\n        </ion-item>\n        <ion-item>\n          <ion-icon name=\"trash\" slot=\"start\"></ion-icon>\n          <button ion-button outline expand=\"block\" routerLink=\"\" routerDirection=\"root\">Delete Account</button>\n        </ion-item>\n        <ion-item>\n          <ion-icon  name=\"log-out\" slot=\"start\"></ion-icon>\n          <button ion-button outline block   expand=\"block\" routerLink=\"/login\" routerDirection=\"root\">Logout</button>\n        </ion-item>\n        <ion-item>\n          <ion-icon name=\"settings\" slot=\"start\"></ion-icon>\n          <button ion-button outline expand=\"block\" routerLink=\"/account-settings\" routerDirection=\"root\">Settings</button>\n        </ion-item>\n      </ion-list>\n    </ion-content>\n  </ion-menu>\n  \n\n  <div class=\"ion-page\" id=\"main-content\" >\n    <ion-header class=\"header\">\n      <ion-toolbar>\n        <ion-buttons slot=\"start\">\n          <ion-menu-button color=\"secondary\"></ion-menu-button>\n        </ion-buttons>\n        <ion-buttons slot=\"end\" (click)=\"onDeletePatient()\">\n          <ion-button color=\"secondary\"  expand=\"block\">\n            <ion-icon  slot=\"icon-only\" name=\"trash\"  class=\"submit\" type=\"submit\" expand=\"block\"> </ion-icon>\n          </ion-button>\n        </ion-buttons>\n        <ion-title color=\"secondary\">{{ loadedPatient.title }}</ion-title>\n      </ion-toolbar>\n    </ion-header>\n\n\n\n\n    <ion-content>\n      <ion-grid>\n        <ion-row>\n         \n        </ion-row>\n        <ion-row>\n          <ion-col>\n            <h2 color=\"secondary\"> Results </h2>\n          </ion-col>\n        </ion-row>\n      </ion-grid>\n    </ion-content>\n\n    <ion-footer>\n      <ion-toolbar>\n        <ion-buttons slot=\"start\">\n          <ion-button color=\"secondary\" expand=\"block\"  routerLink=\"/home\" routerDirection=\"root\">\n            <ion-icon slot=\"icon-only\" name=\"arrow-back\" class=\"submit\" type=\"submit\" expand=\"block\" routerLink=\"/home\" routerDirection=\"root\"></ion-icon>\n          </ion-button>\n        </ion-buttons>\n        <ion-buttons slot=\"end\">\n          <ion-button color=\"secondary\"  class=\"login\" expand=\"block\" routerLink=\"/form\" routerDirection=\"root\">\n            <ion-icon slot=\"icon-only\" name=\"add\"  class=\"submit\" type=\"submit\" expand=\"block\" routerLink=\"/form\" routerDirection=\"root\"> </ion-icon>\n          </ion-button>\n        </ion-buttons>\n      </ion-toolbar>\n    </ion-footer>\n  </div>\n</ion-app>");

/***/ }),

/***/ "./src/app/home/patient-detail/patient-detail-routing.module.ts":
/*!**********************************************************************!*\
  !*** ./src/app/home/patient-detail/patient-detail-routing.module.ts ***!
  \**********************************************************************/
/*! exports provided: PatientDetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientDetailPageRoutingModule", function() { return PatientDetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _patient_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./patient-detail.page */ "./src/app/home/patient-detail/patient-detail.page.ts");




const routes = [
    {
        path: '',
        component: _patient_detail_page__WEBPACK_IMPORTED_MODULE_3__["PatientDetailPage"]
    }
];
let PatientDetailPageRoutingModule = class PatientDetailPageRoutingModule {
};
PatientDetailPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PatientDetailPageRoutingModule);



/***/ }),

/***/ "./src/app/home/patient-detail/patient-detail.module.ts":
/*!**************************************************************!*\
  !*** ./src/app/home/patient-detail/patient-detail.module.ts ***!
  \**************************************************************/
/*! exports provided: PatientDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientDetailPageModule", function() { return PatientDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _patient_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./patient-detail-routing.module */ "./src/app/home/patient-detail/patient-detail-routing.module.ts");
/* harmony import */ var _patient_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./patient-detail.page */ "./src/app/home/patient-detail/patient-detail.page.ts");







let PatientDetailPageModule = class PatientDetailPageModule {
};
PatientDetailPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _patient_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["PatientDetailPageRoutingModule"]
        ],
        declarations: [_patient_detail_page__WEBPACK_IMPORTED_MODULE_6__["PatientDetailPage"]]
    })
], PatientDetailPageModule);



/***/ }),

/***/ "./src/app/home/patient-detail/patient-detail.page.scss":
/*!**************************************************************!*\
  !*** ./src/app/home/patient-detail/patient-detail.page.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".title {\n  font-weight: bold;\n  margin-left: 5%;\n  color: #3dc2ff;\n  font-size: 16px;\n}\n\n.select1 {\n  color: #6a6a6b;\n  margin-left: 2%;\n  text-align: center;\n  background-color: #f5f9fd;\n  font-size: 16px;\n  height: 30px;\n}\n\nbutton {\n  color: #3dc2ff;\n  background-color: white;\n  font-size: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9wYXRpZW50LWRldGFpbC9DOlxcVXNlcnNcXGRpbmlzXFxEZXNrdG9wXFxTREdQXFxmb3JtXFxOZXcgZm9sZGVyXFxBcHA0XFxteUFwcC9zcmNcXGFwcFxcaG9tZVxccGF0aWVudC1kZXRhaWxcXHBhdGllbnQtZGV0YWlsLnBhZ2Uuc2NzcyIsInNyYy9hcHAvaG9tZS9wYXRpZW50LWRldGFpbC9wYXRpZW50LWRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZUFBQTtBQ0NKOztBRENFO0VBQ0UsY0FBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7QUNFSjs7QURBRTtFQUNFLGNBQUE7RUFDQSx1QkFBQTtFQUNBLGVBQUE7QUNHSiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvcGF0aWVudC1kZXRhaWwvcGF0aWVudC1kZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnRpdGxle1xyXG4gICAgZm9udC13ZWlnaHQ6Ym9sZDtcclxuICAgIG1hcmdpbi1sZWZ0OiA1JTtcclxuICAgIGNvbG9yOiAjM2RjMmZmO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gIH1cclxuICAuc2VsZWN0MXtcclxuICAgIGNvbG9yOiAgcmdiKDEwNiwgMTA2LCAxMDcpIDtcclxuICAgIG1hcmdpbi1sZWZ0OiAyJTtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICByZ2IoMjQ1LCAyNDksIDI1Myk7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcbiAgICBoZWlnaHQ6IDMwcHg7XHJcbiAgfVxyXG4gIGJ1dHRvbntcclxuICAgIGNvbG9yOiMzZGMyZmY7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuXHJcbn0iLCIudGl0bGUge1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbWFyZ2luLWxlZnQ6IDUlO1xuICBjb2xvcjogIzNkYzJmZjtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuXG4uc2VsZWN0MSB7XG4gIGNvbG9yOiAjNmE2YTZiO1xuICBtYXJnaW4tbGVmdDogMiU7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y1ZjlmZDtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBoZWlnaHQ6IDMwcHg7XG59XG5cbmJ1dHRvbiB7XG4gIGNvbG9yOiAjM2RjMmZmO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcbiAgZm9udC1zaXplOiAxNnB4O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/home/patient-detail/patient-detail.page.ts":
/*!************************************************************!*\
  !*** ./src/app/home/patient-detail/patient-detail.page.ts ***!
  \************************************************************/
/*! exports provided: PatientDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PatientDetailPage", function() { return PatientDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _home_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../home.service */ "./src/app/home/home.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");





let PatientDetailPage = class PatientDetailPage {
    constructor(activatedRoute, HomeService, router, alertCtrl) {
        this.activatedRoute = activatedRoute;
        this.HomeService = HomeService;
        this.router = router;
        this.alertCtrl = alertCtrl;
    }
    ngOnInit() {
        this.activatedRoute.paramMap.subscribe(paraMap => {
            if (!paraMap.has('patientId')) {
                //redirect
                return;
            }
            const patientId = paraMap.get('patientId');
            this.loadedPatient = this.HomeService.getPatient(patientId);
        });
    }
    onDeletePatient() {
        this.alertCtrl.create({
            header: 'Are you sure?',
            message: 'Do you really want to delete the  Patient detalis?',
            buttons: [{
                    text: 'Cancel',
                    role: 'cancel'
                },
                {
                    text: 'Delete',
                    handler: () => {
                        this.HomeService.deletePatient(this.loadedPatient.title);
                        this.router.navigate(['/home']);
                    }
                }
            ]
        })
            .then(alertEl => {
            alertEl.present();
        });
    }
    doConfirm() {
        this.alertCtrl.create({
            header: 'Are you sure?',
            message: 'Do you really want to Logout?',
            buttons: [{
                    text: 'Cancel',
                    role: 'cancel'
                },
                {
                    text: 'Yes',
                    handler: () => {
                        //this.HomeService.deletePatient(this.loadedPatient.title);
                        this.router.navigate(['/login']);
                    }
                }
            ]
        })
            .then(alertEl => {
            alertEl.present();
        });
    }
};
PatientDetailPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _home_service__WEBPACK_IMPORTED_MODULE_3__["HomeService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] }
];
PatientDetailPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-patient-detail',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./patient-detail.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/patient-detail/patient-detail.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./patient-detail.page.scss */ "./src/app/home/patient-detail/patient-detail.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"],
        _home_service__WEBPACK_IMPORTED_MODULE_3__["HomeService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]])
], PatientDetailPage);



/***/ })

}]);
//# sourceMappingURL=home-patient-detail-patient-detail-module-es2015.js.map