(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["result-result-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/result/result.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/result/result.page.html ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n  <ion-menu side=\"start\" content-id=\"main-content\">\n    <ion-header>\n      <ion-toolbar translucent>\n        <ion-title class=\"title\">Menu</ion-title>\n      </ion-toolbar>\n    </ion-header>\n    <ion-content>\n      <ion-list>\n        <ion-item>\n          <ion-icon  name=\"person-add-outline\" slot=\"start\"></ion-icon>\n          <button ion-button outline block   expand=\"block\" routerLink=\"/add-patient\" routerDirection=\"root\">Add Patient Record</button>\n        </ion-item>\n        <ion-item>\n          <ion-icon name=\"trash\" slot=\"start\"></ion-icon>\n          <button ion-button outline expand=\"block\" routerLink=\"\" routerDirection=\"root\">Delete Account</button>\n        </ion-item>\n        <ion-item>\n          <ion-icon  name=\"log-out\" slot=\"start\"></ion-icon>\n          <button ion-button outline block   expand=\"block\" routerLink=\"/login\" routerDirection=\"root\">Logout</button>\n        </ion-item>\n        <ion-item>\n          <ion-icon name=\"settings\" slot=\"start\"></ion-icon>\n          <button ion-button outline expand=\"block\" routerLink=\"/account-settings\" routerDirection=\"root\">Settings</button>\n        </ion-item>\n      </ion-list>\n    </ion-content>\n  </ion-menu>\n\n  <div class=\"ion-page\" id=\"main-content\" >\n    <ion-header class=\"header\">\n      <ion-toolbar>\n        <ion-buttons slot=\"start\">\n          <ion-menu-button color=\"secondary\"></ion-menu-button>\n        </ion-buttons>\n        <ion-title color=\"secondary\">Result</ion-title>\n      </ion-toolbar>\n    </ion-header>\n\n    <ion-content>\n     \n    </ion-content>\n\n    <ion-footer>\n      <ion-toolbar>\n        <ion-buttons slot=\"start\">\n          <ion-button color=\"secondary\"  expand=\"block\" routerLink=\"/home\" routerDirection=\"root\">\n            <ion-icon slot=\"icon-only\" name=\"arrow-back\"   class=\"submit\" type=\"submit\" expand=\"block\" routerLink=\"/login\" routerDirection=\"root\"></ion-icon>\n          </ion-button>\n        </ion-buttons>\n      \n        <ion-buttons slot=\"end\">\n          <ion-button color=\"secondary\"  class=\"login\" expand=\"block\" routerLink=\"/form\" routerDirection=\"root\">\n            <ion-icon slot=\"icon-only\" name=\"add\"    class=\"submit\" type=\"submit\" expand=\"block\" routerLink=\"/form\" routerDirection=\"root\"> </ion-icon>\n          </ion-button>\n        </ion-buttons>\n      </ion-toolbar>\n    </ion-footer>\n  </div>\n</ion-app>\n");

/***/ }),

/***/ "./src/app/result/result-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/result/result-routing.module.ts ***!
  \*************************************************/
/*! exports provided: ResultPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResultPageRoutingModule", function() { return ResultPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _result_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./result.page */ "./src/app/result/result.page.ts");




const routes = [
    {
        path: '',
        component: _result_page__WEBPACK_IMPORTED_MODULE_3__["ResultPage"]
    }
];
let ResultPageRoutingModule = class ResultPageRoutingModule {
};
ResultPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ResultPageRoutingModule);



/***/ }),

/***/ "./src/app/result/result.module.ts":
/*!*****************************************!*\
  !*** ./src/app/result/result.module.ts ***!
  \*****************************************/
/*! exports provided: ResultPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResultPageModule", function() { return ResultPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _result_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./result-routing.module */ "./src/app/result/result-routing.module.ts");
/* harmony import */ var _result_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./result.page */ "./src/app/result/result.page.ts");







let ResultPageModule = class ResultPageModule {
};
ResultPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _result_routing_module__WEBPACK_IMPORTED_MODULE_5__["ResultPageRoutingModule"]
        ],
        declarations: [_result_page__WEBPACK_IMPORTED_MODULE_6__["ResultPage"]]
    })
], ResultPageModule);



/***/ }),

/***/ "./src/app/result/result.page.scss":
/*!*****************************************!*\
  !*** ./src/app/result/result.page.scss ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("button {\n  color: #3dc2ff;\n  background-color: white;\n  font-size: 16px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvcmVzdWx0L0M6XFxVc2Vyc1xcZGluaXNcXERlc2t0b3BcXFNER1BcXGZvcm1cXE5ldyBmb2xkZXJcXEFwcDRcXG15QXBwL3NyY1xcYXBwXFxyZXN1bHRcXHJlc3VsdC5wYWdlLnNjc3MiLCJzcmMvYXBwL3Jlc3VsdC9yZXN1bHQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksY0FBQTtFQUNBLHVCQUFBO0VBQ0EsZUFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvcmVzdWx0L3Jlc3VsdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJidXR0b257XHJcbiAgICBjb2xvcjojM2RjMmZmO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgICBmb250LXNpemU6IDE2cHg7XHJcblxyXG59IiwiYnV0dG9uIHtcbiAgY29sb3I6ICMzZGMyZmY7XG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xuICBmb250LXNpemU6IDE2cHg7XG59Il19 */");

/***/ }),

/***/ "./src/app/result/result.page.ts":
/*!***************************************!*\
  !*** ./src/app/result/result.page.ts ***!
  \***************************************/
/*! exports provided: ResultPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ResultPage", function() { return ResultPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");


let ResultPage = class ResultPage {
    constructor() { }
    ngOnInit() {
    }
};
ResultPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-result',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./result.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/result/result.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./result.page.scss */ "./src/app/result/result.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
], ResultPage);



/***/ })

}]);
//# sourceMappingURL=result-result-module-es2015.js.map