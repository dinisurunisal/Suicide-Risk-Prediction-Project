import { Component, OnInit } from '@angular/core';
import { Patient } from './home.module';
import { PatientsService } from './patients.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
  patients: Patient[];


  constructor(private patientsService: PatientsService){}

  ngOnInit() {
   this.patients = this.patientsService.gellAllPatients();
  }

}
