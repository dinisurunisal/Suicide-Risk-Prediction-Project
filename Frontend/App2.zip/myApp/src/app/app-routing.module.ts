import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'welcome', pathMatch: 'full' },
  {
    path: 'welcome', loadChildren: () => import('./welcome/welcome.module').then( m => m.WelcomePageModule)
  },
  { 
    path: 'login', 
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'home',
    children:[
      {  
       path: '',
      loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
      },
      {
        path: 'title',
        children:[
          {
            path:'',
            loadChildren: () => import('./patient-details/patient-details.module').then( m => m.PatientDetailsPageModule),
          },
          {
            path: 'resultId',
            loadChildren: () => import('./result/result.module').then( m => m.ResultPageModule)
          },
        ]
      },
    ]
  },
  {
    path: 'form',
      loadChildren: () => import('./form/form.module').then( m => m.FormPageModule)
  },
  
  {
    path: 'add-patient',
    loadChildren: () => import('./add-patient/add-patient.module').then( m => m.AddPatientPageModule)
  },
  {
    path: 'account-settings',
    loadChildren: () => import('./account-settings/account-settings.module').then( m => m.AccountSettingsPageModule)
  },
]
 

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
