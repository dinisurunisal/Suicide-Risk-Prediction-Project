import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Details } from './patient-details.module';
import { DetailsService } from './details.service';

@Component({
  selector: 'app-patient-details',
  templateUrl: './patient-details.page.html',
  styleUrls: ['./patient-details.page.scss'],
})
export class PatientDetailsPage implements OnInit {
  details: Details [] = [
    {
      id:'result1',
      result:' '
    },
    {
      id:'result2',
      result:' '
    }
    
  ]

  loadedDetails: Details;

  constructor(private activatedRoute: ActivatedRoute, private DetailsService:DetailsService) { }

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(paraMap => {
      if(!paraMap.has('result')){
        //redirect
        return;
        const result = paraMap.get('result');
        this.loadedDetails = this.DetailsService.getDetails(result);

      }
    });
  }

}
